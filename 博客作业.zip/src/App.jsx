import React, { Component } from 'react'
import BaseRouter from '@/router/index'

class App extends Component {
    render() {
        return (
            <div>

                <BaseRouter></BaseRouter>
            </div>
        )
    }
}
export default App;








