import React from 'react'
import Style from '@/css/style'
const Footer=()=>{
    return (
        <div className={Style.footer}>
            &copy;页面版权归图图所有！
        </div>
    )
}
export default Footer;