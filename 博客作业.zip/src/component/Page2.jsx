import React from 'react'
import Style from '@/css/style'
const Page2=()=>{
    return (
        <div className={Style.content}>
            <h2>Page2组件</h2>
            <h3>前端资源:</h3>
            <p>
              前端工程师必备的技术网站w3ctech web标准化交流会前端观察
              专注于网站前端设计与前端开发Web App Trend 关注跨平台开发以及Web
              App技术发展与实践前端开发
            </p>
        </div>
    )
}
export default Page2;