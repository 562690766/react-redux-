import React from 'react'
import Style from '@/css/style'
const Page3=()=>{
    return (
        <div className={Style.content}>
            <h2>Page3组件</h2>
            <h3>技术分享:</h3>
            <p>
                react全栈工程师
            </p>
        </div>
    )
}
export default Page3;