import React from 'react'
import Style from '@/css/style1.css'
const Child2=()=>{
    return (
        <div className={Style['child-container']}>
            <h3>Child2页面面面面</h3>
        </div>
    )
}
export default Child2;